INITIAL_PUNCT_MAP = {'': 0, '¿': 1}
FINAL_PUNCT_MAP = {'': 0, ',': 1, '.': 2, '?': 3}
TOKENIZER_EMBEDDING_MODEL_NAME = "bert-base-multilingual-cased"